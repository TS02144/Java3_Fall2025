package poly.com.controller;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import poly.com.controller.User;

@WebServlet("/bai4")
public class bai4 extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User bean = new User();
        bean.setFullname("Nguyễn Văn Sơn");
        bean.setGender(true);
        bean.setCountry("VN");
        req.setAttribute("user", bean);

        // Chuyển tới trang JSP để hiển thị thông tin
        req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
    }
}
