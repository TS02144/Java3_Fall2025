package com.poly.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AppFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) 
            throws IOException, ServletException {
        
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession();

        // 1. ĐA NGÔN NGỮ: Bắt tham số ?lang=vi hoặc ?lang=en
        String lang = request.getParameter("lang");
        if (lang != null) {
            session.setAttribute("lang", lang);
        }

        // 2. BẢO MẬT: Chặn đường dẫn chứa /admin/
        String uri = request.getRequestURI();
        if (uri.contains("/admin/")) {
            // Nếu chưa có user trong session -> Đá về login
            if (session.getAttribute("user") == null) {
                response.sendRedirect(request.getContextPath() + "/login?error=true");
                return; // Dừng lại, không cho vào admin
            }
        }

        chain.doFilter(req, resp); // Cho qua
    }

    @Override
    public void destroy() {}
}