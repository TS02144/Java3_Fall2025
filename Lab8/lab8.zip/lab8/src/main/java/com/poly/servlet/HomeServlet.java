package com.poly.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet({"/home/index", "/home/about"})
public class HomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String uri = req.getRequestURI();
        if (uri.contains("index")) {
            req.setAttribute("view", "/views/home/index.jsp");
        } else if (uri.contains("about")) {
            req.setAttribute("view", "/views/home/about.jsp");
        }
        req.getRequestDispatcher("/views/layout.jsp").forward(req, resp);
    }
}