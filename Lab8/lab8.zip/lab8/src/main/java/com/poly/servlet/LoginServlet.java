package com.poly.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet({"/login", "/logout"})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String uri = req.getRequestURI();
        if (uri.contains("logout")) {
            req.getSession().invalidate(); 
            resp.sendRedirect("home/index");
        } else {
            // SỬA: Chạy thẳng trang login.jsp, không qua layout nữa
            req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        String user = req.getParameter("username");
        String pass = req.getParameter("password");

        if ("admin".equals(user) && "123".equals(pass)) {
            HttpSession session = req.getSession();
            session.setAttribute("user", user); 
            resp.sendRedirect("admin/index");
        } else {
            req.setAttribute("message", "Sai thông tin đăng nhập!");
            // SỬA: Nếu sai pass, quay lại thẳng trang login.jsp
            req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
        }
    }
}