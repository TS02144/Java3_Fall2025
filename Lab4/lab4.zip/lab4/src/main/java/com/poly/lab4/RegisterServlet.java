package com.poly.lab4;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");
        String[] hobbies = req.getParameterValues("hobbies");

        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        System.out.println("Gender: " + gender);
        System.out.println("Country: " + country);

        if (hobbies != null) {
            for (String h : hobbies) {
                System.out.println("Hobby: " + h);
            }
        }

        req.setAttribute("message", "Đã in tham số ra console");
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }
}