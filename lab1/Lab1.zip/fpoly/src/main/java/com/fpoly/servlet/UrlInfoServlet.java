package com.fpoly.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/urlinfo/*")
public class UrlInfoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String url = request.getRequestURL().toString();
        String uri = request.getRequestURI();
        String queryString = request.getQueryString();
        String servletPath = request.getServletPath();
        String contextPath = request.getContextPath();
        String pathInfo = request.getPathInfo();
        String method = request.getMethod();

        out.println("<html><head><meta charset='UTF-8'><title>URL Info</title></head><body>");
        out.println("<h2>Thông tin địa chỉ URL:</h2>");
        out.println("<ul>");
        out.println("<li><b>URL:</b> " + url + "</li>");
        out.println("<li><b>URI:</b> " + uri + "</li>");
        out.println("<li><b>Query String:</b> " + queryString + "</li>");
        out.println("<li><b>Servlet Path:</b> " + servletPath + "</li>");
        out.println("<li><b>Context Path:</b> " + contextPath + "</li>");
        out.println("<li><b>Path Info:</b> " + pathInfo + "</li>");
        out.println("<li><b>Method:</b> " + method + "</li>");
        out.println("</ul>");
        out.println("</body></html>");
    }
}
