package com.fpoly.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Ánh xạ nhiều URL cùng một Servlet
@WebServlet(urlPatterns = {"/crud/create", "/crud/update", "/crud/delete", "/crud/edit/*"})
public class CrudServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        // Lấy đường dẫn thực tế của request
        String path = request.getServletPath();  // /crud/create, /crud/update, /crud/delete
        String pathInfo = request.getPathInfo(); // /2024 khi URL là /crud/edit/2024

        // Kiểm tra và in thông báo tương ứng
        if ("/crud/create".equals(path)) {
            out.println("Đây là trang CREATE");
        } else if ("/crud/update".equals(path)) {
            out.println("Đây là trang UPDATE");
        } else if ("/crud/delete".equals(path)) {
            out.println("Đây là trang DELETE");
        } else if ("/crud/edit".equals(path)) {
            out.println("Đây là trang EDIT với ID: " + (pathInfo != null ? pathInfo.substring(1) : "không có ID"));
        } else {
            out.println("Không xác định URL");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
