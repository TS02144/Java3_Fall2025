package com.servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebServlet("/bai4")
public class Bai4Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Map<String, Object> news = new HashMap<>();
        news.put("title", "Tiêu đề bản tin");
        news.put("content", "Đây là nội dung rất dài, vượt quá 100 ký tự để kiểm tra cắt chuỗi hiển thị trong JSP. Hệ thống sẽ cắt ngắn và thêm dấu ... ở cuối.");

        req.setAttribute("news", news);
        req.getRequestDispatcher("/WEB-INF/views/bai4.jsp").forward(req, resp);
    }
}
