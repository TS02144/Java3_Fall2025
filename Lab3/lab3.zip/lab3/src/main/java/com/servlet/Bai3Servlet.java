package com.servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebServlet("/bai3")
public class Bai3Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Map<String, Object> item = new HashMap<>();
        item.put("name", "iPhone 2024");
        item.put("price", 12345.678);
        item.put("date", new Date());

        req.setAttribute("item", item);
        req.getRequestDispatcher("/WEB-INF/views/bai3.jsp").forward(req, resp);
    }
}

