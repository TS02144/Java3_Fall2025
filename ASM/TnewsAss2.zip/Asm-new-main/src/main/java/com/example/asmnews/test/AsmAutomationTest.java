package com.example.asmnews.test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class AsmAutomationTest {

    private WebDriver driver;
    private WebDriverWait wait;

    // --- CẤU HÌNH ---
    private String BASE_URL = "http://localhost:8080/asm-news"; 
    private String USERNAME_ADMIN = "admin"; 
    private String PASSWORD_ADMIN = "123456";

    // Dữ liệu test
    private String TEST_USER_ID = "reporter7";
    private String TEST_USER_NAME_OLD = "Tèo bé"; // Tên lúc tạo
    private String TEST_USER_NAME_NEW = "Tèo bự"; // Tên sau khi sửa
    private String TEST_USER_EMAIL = "cuteobe@gmail.com";

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void sleep(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 1)
    public void testLogin() {
        System.out.println("--- Bắt đầu Test 1: Đăng nhập ---");
        driver.get(BASE_URL + "/login");
        sleep(2);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username"))).sendKeys(USERNAME_ADMIN);
        sleep(1);
        driver.findElement(By.id("password")).sendKeys(PASSWORD_ADMIN);
        sleep(1);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        sleep(3);

        Assert.assertTrue(driver.getCurrentUrl().contains("admin"), "Đăng nhập thất bại!");
        System.out.println("-> Đăng nhập thành công!");
    }

    @Test(priority = 2)
    public void testCreateUser() {
        System.out.println("--- Bắt đầu Test 2: Thêm người dùng (Admin) ---");
        driver.get(BASE_URL + "/admin/users");
        sleep(2);

        // Bấm nút thêm
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@onclick, 'showAddUserModal')]"))).click();
        sleep(2);

        // Điền form
        driver.findElement(By.id("userId")).sendKeys(TEST_USER_ID);
        sleep(1);
        driver.findElement(By.id("userFullname")).sendKeys(TEST_USER_NAME_OLD);
        sleep(1);
        driver.findElement(By.id("userEmail")).sendKeys(TEST_USER_EMAIL);
        sleep(1);
        driver.findElement(By.id("userPassword")).sendKeys("123456");
        sleep(1);

        // Chọn quyền QUẢN TRỊ (Admin)
        WebElement roleAdmin = driver.findElement(By.id("roleAdmin"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", roleAdmin);
        sleep(2); // Dừng để nhìn thấy đang chọn Admin

        driver.findElement(By.id("saveUserBtn")).click();
        sleep(3);

        // Kiểm tra tạo thành công
        Assert.assertTrue(driver.getPageSource().contains(TEST_USER_ID), "Thêm mới thất bại!");
        System.out.println("-> Thêm user thành công!");
    }

    @Test(priority = 3)
    public void testEditUser() {
        System.out.println("--- Bắt đầu Test 3: Sửa người dùng (Đổi tên & thành Phóng viên) ---");
        // Đảm bảo đang ở trang danh sách
        driver.get(BASE_URL + "/admin/users");
        sleep(2);

        // 1. Tìm nút SỬA của user vừa tạo
        // XPath: Tìm dòng chứa ID user -> tìm nút có chứa hàm 'editUser'
        String xpathEdit = String.format("//tr[contains(., '%s')]//button[contains(@onclick, 'editUser')]", TEST_USER_ID);
        WebElement editBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathEdit)));
        
        // Scroll xuống nếu bị che
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", editBtn);
        sleep(1);
        
        editBtn.click(); // Bấm nút sửa
        sleep(2); // Chờ Modal hiện ra

        // 2. Đổi tên hiển thị
        WebElement nameField = driver.findElement(By.id("userFullname"));
        nameField.clear(); // Xóa tên cũ đi
        sleep(1);
        nameField.sendKeys(TEST_USER_NAME_NEW); // Nhập tên mới
        sleep(1);

        // 3. Đổi quyền sang PHÓNG VIÊN (Reporter)
        // ID của radio button phóng viên là "roleReporter" (theo file jsp bạn gửi)
        WebElement roleReporter = driver.findElement(By.id("roleReporter"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", roleReporter);
        sleep(2); // Dừng để nhìn thấy đã chọn Phóng viên

        // 4. Lưu lại
        driver.findElement(By.id("saveUserBtn")).click();
        sleep(3); // Chờ load lại trang

        // 5. Kiểm tra kết quả
        String pageSource = driver.getPageSource();
        // Phải tìm thấy tên mới
        Assert.assertTrue(pageSource.contains(TEST_USER_NAME_NEW), "Lỗi: Không tìm thấy tên mới sau khi sửa!");
        // Không được tìm thấy tên cũ nữa (nếu muốn check kỹ)
        Assert.assertFalse(pageSource.contains(TEST_USER_NAME_OLD), "Lỗi: Tên cũ vẫn còn!");
        
        System.out.println("-> Sửa user thành công (Đã đổi tên và quyền)!");
    }

    @Test(priority = 4)
    public void testDeleteUser() {
        System.out.println("--- Bắt đầu Test 4: Xóa người dùng ---");
        driver.get(BASE_URL + "/admin/users");
        sleep(2);

        // Tìm nút xóa (Vẫn dùng ID để tìm, vì ID không thay đổi khi sửa)
        String xpathDelete = String.format("//tr[contains(., '%s')]//button[contains(@onclick, 'deleteUser')]", TEST_USER_ID);
        WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathDelete)));
        
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", deleteBtn);
        sleep(1);
        
        deleteBtn.click();
        sleep(2); 

        // Xác nhận xóa
        driver.findElement(By.id("confirmDelete")).click();
        sleep(3); 

        // Kiểm tra bay màu chưa
        Assert.assertFalse(driver.getPageSource().contains(TEST_USER_ID), "Xóa thất bại! User vẫn còn.");
        System.out.println("-> Xóa user thành công!");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}