package com.poly.controller;

import com.poly.utils.Jdbc;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/lab6")
public class Lab6Controller extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        String message = "";
        List<String> results = new ArrayList<>();

        try {
            if ("bai2".equals(action)) {
                // Bài 2: Truy vấn cơ bản (Statement)
                String sql = "SELECT * FROM Departments";
                ResultSet rs = Jdbc.executeQuery(sql);
                while (rs.next()) {
                    results.add(rs.getString("Id") + " - " + rs.getString("Name"));
                }
                message = "Kết quả Bài 2 (Statement - Select All):";

            } else if ("bai3".equals(action)) {
                // Bài 3: Thêm mới dùng PreparedStatement (có tham số ?)
                String id = "M" + (System.currentTimeMillis() % 100); 
                String sqlInsert = "INSERT INTO Departments(Id, Name, Description) VALUES(?, ?, ?)";
                
                // Thực thi thêm mới
                Jdbc.executeUpdate(sqlInsert, id, "Marketing " + id, "Phong Marketing");
                
                message = "Đã thêm phòng Marketing (ID: " + id + ") thành công.";
                
                // Load lại danh sách để kiểm chứng
                ResultSet rs = Jdbc.executeQuery("SELECT * FROM Departments");
                while (rs.next()) {
                    results.add(rs.getString("Id") + " - " + rs.getString("Name"));
                }

            } else if ("bai4".equals(action)) {
                // Bài 4: Gọi Stored Procedure (CallableStatement)
                String sql = "{CALL spSelectAll()}";
                ResultSet rs = Jdbc.executeQuery(sql);
                while (rs.next()) {
                    results.add(rs.getString("Id") + " - " + rs.getString("Name"));
                }
                message = "Kết quả Bài 4 (Gọi Stored Procedure spSelectAll):";
            }
        } catch (Exception e) {
            message = "Lỗi: " + e.getMessage();
            e.printStackTrace();
        }

        req.setAttribute("message", message);
        req.setAttribute("results", results);
        req.getRequestDispatcher("/index.jsp").forward(req, resp);
    }
}
