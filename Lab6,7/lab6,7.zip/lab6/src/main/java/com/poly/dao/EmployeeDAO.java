package com.poly.dao;

import com.poly.model.Employee;
import com.poly.utils.Jdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    public List<Employee> findAll() {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM Employees";
        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while(rs.next()){
                list.add(new Employee(
                    rs.getString("Id"), rs.getString("Password"), rs.getString("Fullname"),
                    rs.getString("Photo"), rs.getBoolean("Gender"), rs.getDate("Birthday"),
                    rs.getDouble("Salary"), rs.getString("DepartmentId")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Employee findById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if(rs.next()){
                return new Employee(
                    rs.getString("Id"), rs.getString("Password"), rs.getString("Fullname"),
                    rs.getString("Photo"), rs.getBoolean("Gender"), rs.getDate("Birthday"),
                    rs.getDouble("Salary"), rs.getString("DepartmentId")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public void create(Employee emp) throws Exception {
        String sql = "INSERT INTO Employees VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        Jdbc.executeUpdate(sql, emp.getId(), emp.getPassword(), emp.getFullname(),
                emp.getPhoto(), emp.isGender(), emp.getBirthday(), emp.getSalary(), emp.getDepartmentId());
    }

    public void update(Employee emp) throws Exception {
        String sql = "UPDATE Employees SET Password=?, Fullname=?, Photo=?, Gender=?, Birthday=?, Salary=?, DepartmentId=? WHERE Id=?";
        Jdbc.executeUpdate(sql, emp.getPassword(), emp.getFullname(),
                emp.getPhoto(), emp.isGender(), emp.getBirthday(), emp.getSalary(), emp.getDepartmentId(), emp.getId());
    }

    public void delete(String id) throws Exception {
        String sql = "DELETE FROM Employees WHERE Id=?";
        Jdbc.executeUpdate(sql, id);
    }
}