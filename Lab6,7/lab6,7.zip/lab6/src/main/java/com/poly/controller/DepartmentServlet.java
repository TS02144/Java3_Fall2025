package com.poly.controller;

import com.poly.dao.DepartmentDAO;
import com.poly.model.Department;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet({"/department", "/department/create", "/department/update", "/department/delete", "/department/edit", "/department/reset"})
public class DepartmentServlet extends HttpServlet {
    DepartmentDAO dao = new DepartmentDAO();

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();
        Department form = new Department(); // Đối tượng để hiển thị lên form
        String message = "";

        try {
            if (uri.contains("edit")) { // Chức năng Edit (Đẩy dữ liệu lên form)
                String id = req.getParameter("id");
                form = dao.findById(id);
            } else if (uri.contains("create")) { // Chức năng Thêm
                String id = req.getParameter("id");
                String name = req.getParameter("name");
                String desc = req.getParameter("description");
                dao.create(new Department(id, name, desc));
                message = "Thêm mới thành công!";
            } else if (uri.contains("update")) { // Chức năng Sửa
                String id = req.getParameter("id");
                String name = req.getParameter("name");
                String desc = req.getParameter("description");
                dao.update(new Department(id, name, desc));
                message = "Cập nhật thành công!";
            } else if (uri.contains("delete")) { // Chức năng Xóa
                String id = req.getParameter("id");
                dao.delete(id);
                message = "Xóa thành công!";
            } else if (uri.contains("reset")) {
                form = new Department(); // Xóa trắng form
            }
        } catch (Exception e) {
            message = "Lỗi: " + e.getMessage();
        }

        req.setAttribute("message", message);
        req.setAttribute("form", form); // Gửi đối tượng form sang JSP
        req.setAttribute("items", dao.findAll()); // Gửi danh sách sang JSP
        req.getRequestDispatcher("/views/department.jsp").forward(req, resp);
    }
}
