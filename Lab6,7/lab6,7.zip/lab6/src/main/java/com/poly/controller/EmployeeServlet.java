package com.poly.controller;

import com.poly.dao.DepartmentDAO;
import com.poly.dao.EmployeeDAO;
import com.poly.model.Employee;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet({"/employee", "/employee/create", "/employee/update", "/employee/delete", "/employee/edit", "/employee/reset"})
public class EmployeeServlet extends HttpServlet {
    EmployeeDAO empDao = new EmployeeDAO();
    DepartmentDAO deptDao = new DepartmentDAO();

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String uri = req.getRequestURI();
        Employee form = new Employee();
        String message = "";

        try {
            // Lấy dữ liệu từ form (nếu có POST)
            String id = req.getParameter("id");
            String pw = req.getParameter("password");
            String name = req.getParameter("fullname");
            String photo = req.getParameter("photo");
            boolean gender = Boolean.parseBoolean(req.getParameter("gender"));
            double salary = req.getParameter("salary") != null ? Double.parseDouble(req.getParameter("salary")) : 0;
            String deptId = req.getParameter("departmentId");
            
            // Xử lý ngày tháng
            Date birthday = new Date();
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                birthday = sdf.parse(req.getParameter("birthday"));
            } catch (Exception e) {}

            Employee model = new Employee(id, pw, name, photo, gender, birthday, salary, deptId);

            if (uri.contains("edit")) {
                String editId = req.getParameter("id");
                form = empDao.findById(editId);
            } else if (uri.contains("create")) {
                empDao.create(model);
                message = "Thêm nhân viên thành công!";
            } else if (uri.contains("update")) {
                empDao.update(model);
                message = "Cập nhật nhân viên thành công!";
            } else if (uri.contains("delete")) {
                empDao.delete(id);
                message = "Xóa nhân viên thành công!";
            } else if (uri.contains("reset")) {
                form = new Employee();
            }
        } catch (Exception e) {
            message = "Lỗi: " + e.getMessage();
            e.printStackTrace();
        }

        req.setAttribute("message", message);
        req.setAttribute("form", form);
        req.setAttribute("items", empDao.findAll()); // DS Nhân viên
        req.setAttribute("depts", deptDao.findAll()); // DS Phòng ban để đổ vào ComboBox
        req.getRequestDispatcher("/views/employee.jsp").forward(req, resp);
    }
}