package com.poly.dao;

import com.poly.model.Department;
import com.poly.utils.Jdbc;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDAO {
    
    public List<Department> findAll() {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM Departments";
        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while(rs.next()){
                list.add(new Department(rs.getString("Id"), rs.getString("Name"), rs.getString("Description")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Department findById(String id) {
        String sql = "SELECT * FROM Departments WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if(rs.next()){
                return new Department(rs.getString("Id"), rs.getString("Name"), rs.getString("Description"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public void create(Department dep) throws Exception {
        String sql = "INSERT INTO Departments(Id, Name, Description) VALUES(?, ?, ?)";
        Jdbc.executeUpdate(sql, dep.getId(), dep.getName(), dep.getDescription());
    }

    public void update(Department dep) throws Exception {
        String sql = "UPDATE Departments SET Name=?, Description=? WHERE Id=?";
        Jdbc.executeUpdate(sql, dep.getName(), dep.getDescription(), dep.getId());
    }

    public void delete(String id) throws Exception {
        String sql = "DELETE FROM Departments WHERE Id=?";
        Jdbc.executeUpdate(sql, id);
    }
}