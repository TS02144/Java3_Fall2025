package com.lab5.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.apache.commons.codec.binary.Base64;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie ck : cookies) {
                if (ck.getName().equals("user")) {
                    String encoded = ck.getValue();
                    byte[] decodedBytes = Base64.decodeBase64(encoded);
                    String[] userInfo = new String(decodedBytes).split(",");

                    req.setAttribute("username", userInfo[0]);
                    req.setAttribute("password", userInfo[1]);
                }
            }
        }

        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String remember = req.getParameter("remember-me");

        // Tài khoản đúng như Lab yêu cầu
        if (username.equalsIgnoreCase("FPT") && password.equals("poly")) {

            req.setAttribute("message", "Login successfully!");

            // Lưu session
            req.getSession().setAttribute("username", username);

            // Lưu cookie nếu chọn Remember me
            if (remember != null) {
                byte[] bytes = (username + "," + password).getBytes();
                String encoded = Base64.encodeBase64String(bytes);

                Cookie cookie = new Cookie("user", encoded);
                cookie.setMaxAge(30 * 24 * 60 * 60); // 30 ngày
                cookie.setPath("/");

                resp.addCookie(cookie);
            }

        } else {
            req.setAttribute("message", "Invalid login info!");
        }

        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }
}
