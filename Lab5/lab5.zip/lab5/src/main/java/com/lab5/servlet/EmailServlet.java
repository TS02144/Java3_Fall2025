package com.lab5.servlet;

import com.lab5.utils.Mailer;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/send-email")
public class EmailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/email.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8"); // Đảm bảo tiếng Việt không lỗi
        resp.setCharacterEncoding("UTF-8");

        // Lấy thông tin từ form
        String userEmail = req.getParameter("from"); // Email khách hàng nhập
        String to = req.getParameter("to");          // Email nhận (nguyenson...)
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            // Gọi hàm gửi mail
            Mailer.send(userEmail, to, subject, body);
            
            // Nếu chạy đến đây tức là thành công
            req.setAttribute("message", "Gửi email thành công!");
            System.out.println(">> Đã gửi mail thành công tới: " + to);

        } catch (Exception e) {
            // Nếu có lỗi, in lỗi ra Console để xem
            System.out.println(">> GỬI MAIL THẤT BẠI. CHI TIẾT LỖI BÊN DƯỚI:");
            e.printStackTrace(); 
            
            req.setAttribute("message", "Gửi email thất bại! Lỗi: " + e.getMessage());
        }

        req.getRequestDispatcher("/email.jsp").forward(req, resp);
    }
}