package com.lab5.servlet;

import com.lab5.entity.Staff;
import java.io.IOException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

@WebServlet("/save")
public class SaveServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/save.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Staff bean = new Staff();

        try {
            // convert định dạng ngày
            DateConverter dtc = new DateConverter(new Date());
            dtc.setPattern("MM/dd/yyyy");
            ConvertUtils.register(dtc, Date.class);

            // populate dữ liệu vào bean
            BeanUtils.populate(bean, req.getParameterMap());

            System.out.println("----- Staff Info -----");
            System.out.println("Fullname: " + bean.getFullname());
            System.out.println("Birthday: " + bean.getBirthday());
            System.out.println("Gender: " + bean.isGender());
            System.out.println("Country: " + bean.getCountry());
            System.out.println("Salary: " + bean.getSalary());

            if (bean.getHobbies() != null) {
                System.out.print("Hobbies: ");
                for (String h : bean.getHobbies()) {
                    System.out.print(h + " ");
                }
                System.out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        req.setAttribute("message", "Đã đọc dữ liệu form! Xem console để kiểm tra.");
        req.getRequestDispatcher("/save.jsp").forward(req, resp);
    }
}
