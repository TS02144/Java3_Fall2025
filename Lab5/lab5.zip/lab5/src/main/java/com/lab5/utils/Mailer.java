package com.lab5.utils;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class Mailer {

    // Thêm 'throws Exception' để báo lỗi về cho Servlet xử lý
    public static void send(String userEmail, String to, String subject, String body) throws Exception {

        // 1. Cấu hình SMTP Gmail
        Properties props = new Properties();
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");
        props.setProperty("mail.smtp.host", "smtp.gmail.com");
        props.setProperty("mail.smtp.port", "587");
        props.setProperty("mail.smtp.ssl.protocols", "TLSv1.2"); // Bổ sung để tránh lỗi SSL cũ

        // 2. Tài khoản Gmail thực hiện gửi (CỐ ĐỊNH)
        final String myAccountEmail = "zodiacroyalerestaurant@gmail.com";
        final String myAccountPassword = "ghph gezk xuxk lskd"; 

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myAccountEmail, myAccountPassword);
            }
        });

        // 3. Tạo nội dung email
        MimeMessage mail = new MimeMessage(session);

        // QUAN TRỌNG: Người gửi (From) PHẢI LÀ email đăng nhập bên trên
        mail.setFrom(new InternetAddress(myAccountEmail));

        // Thiết lập Reply-To: Khi bấm trả lời, sẽ gửi về email người dùng nhập
        if (userEmail != null && !userEmail.isEmpty()) {
            mail.setReplyTo(new InternetAddress[]{new InternetAddress(userEmail)});
        }

        // Người nhận
        mail.setRecipients(Message.RecipientType.TO, to);
        
        // Chủ đề và nội dung
        mail.setSubject(subject, "utf-8");
        mail.setText(body, "utf-8", "html");

        // 4. Gửi mail
        Transport.send(mail);
    }
}